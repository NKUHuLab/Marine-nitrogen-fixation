############################################################################################
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error,mean_absolute_error,make_scorer
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
import warnings
warnings.filterwarnings("ignore")
import joblib
from sklearn.feature_selection import RFECV

data = pd.read_csv(r"data.csv")
data.info()
data.describe()
sum(data.duplicated()) == 0
data.isnull().sum()
x=data[data.columns[:-1]]
y=data[data.columns[-1:]]
y=np.log10(y)

X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2,random_state=42)
def cor_R2(y_test, preds):
    y_test=np.array(y_test).ravel()
    cor2=np.corrcoef(y_test,preds)[0,1]
    return cor2
score = make_scorer(cor_R2)
model=RandomForestRegressor( n_estimators=650, max_features=8,random_state=42)
model.fit(X_train,y_train)
y_train_pred=model.predict(X_train)
y_test_pred=model.predict(X_test)
print('test R2：',cor_R2(y_test,y_test_pred))
print('train R2：',cor_R2(y_train,y_train_pred))
print('test RMSE：',np.sqrt(mean_squared_error(y_test,y_test_pred)))
print('train RMSE：',np.sqrt(mean_squared_error(y_train,y_train_pred)))
print('test MAE：',mean_absolute_error(y_test,y_test_pred))
print('train MAE：',mean_absolute_error(y_train,y_train_pred))
joblib.dump(model, 'model.pkl')

param = {'n_estimators': [650,700],'max_features': [7,8,9]}
model = GridSearchCV(estimator=RandomForestRegressor(random_state=42), 
                     param_grid=param, cv=10,scoring=score,refit=True)
model.fit(X_train,y_train)
print(model.best_params_)
print(model.best_score_ )

model=joblib.load('model.pkl')
kf=KFold(n_splits=10,shuffle=True,random_state=42)
x_names=x.columns.values.tolist()
colnames=y.columns.values.tolist()
corlist_train=[]
corlist_test=[]
rmsel_train=[]
rmsel_test=[]
ytestlist=[]
ypredlist=[]
o=[]
def rmse(obs,pre):
    return np.sqrt(mean_squared_error(obs, pre))
for train_index , test_index in kf.split(x,y):
    x_train=x.iloc[train_index,:]
    x_train.columns=x_names
    y_train=y.iloc[train_index,:]
    x_test=x.iloc[test_index,:]
    x_test.columns=x_names
    y_test=y.iloc[test_index,:]
    model.fit(x_train,np.array(y_train).ravel())
    y_test_pred=pd.DataFrame(model.predict(x_test).reshape(y_test.shape),index=test_index)
    r_test=np.corrcoef(y_test_pred[0],y_test[colnames[0]])
    y_train_pred=pd.DataFrame(model.predict(x_train).reshape(y_train.shape),index=train_index)
    r_train=np.corrcoef(y_train_pred[0],y_train[colnames[0]])
    rmse_test=rmse(y_test[colnames[0]],y_test_pred[0])
    rmse_train=rmse(y_train[colnames[0]],y_train_pred[0])
    corlist_train.append(r_train[1,0])
    corlist_test.append(r_test[1,0])
    rmsel_train.append(rmse_train)
    rmsel_test.append(rmse_test)
    ytestlist.append(y_test[colnames[0]])
    ypredlist.append(y_test_pred[0]) 
    o.append(y_train[colnames[0]])
    o.append(y_train_pred[0])
    o.append(y_test[colnames[0]])
    o.append(y_test_pred[0])

obs_pre_df=pd.DataFrame([y[colnames[0]],o[1],o[5],o[9],o[13],o[17],o[21],o[25],o[29],o[33],o[37],
                        o[3],o[7],o[11],o[15],o[19],o[23],o[27],o[31],o[35],o[39]]).T
obs_pre_df.columns=(colnames[0],'train1','train2','train3','train4','train5',
                    'train6','train7','train8','train9','train10',
                    'test1','test2','test3','test4','test5',
                    'test6','test7','test8','test9','test10')
cordf=pd.DataFrame({'train':corlist_train,'test':corlist_test,
                    'rmse_train':rmsel_train,'rmse_test':rmsel_test})

rf = joblib.load("model.pkl")        
cv=KFold(n_splits=10,shuffle=True,random_state=42)
rfecv = RFECV(estimator=rf,scoring='r2', cv=cv,n_jobs=-1,min_features_to_select=1)
x_data=x.values
y_data=y.values
rfecv.fit(x_data,y_data)
print(rfecv.n_features_)
print(rfecv.ranking_)
print(rfecv.support_)
print(rfecv.estimator_)
print(rfecv.grid_scores_)
print(rfecv.cv_results_['mean_test_score'])

model=RandomForestRegressor( n_estimators=650, max_features=8,random_state=42,oob_score=True)
model.fit(X_train,y_train)
model.oob_score_
y_oob_pred=model.oob_prediction_
cor_R2(y_train,y_oob_pred)
